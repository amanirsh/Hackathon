package com.example.web2;


import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;




import com.example.web2.SQLiteHandler;
import com.example.web2.SessionManager;


 
import java.util.HashMap;
 
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
 
public class MainActivity extends Activity {
 
    private TextView txtName ;
    private TextView txtEmail;
    private Button btnLogout;
    
    Button submit;
    Button health;
    private SQLiteHandler db;
    private SessionManager session;
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
 
        txtName = (TextView) findViewById(R.id.name);
        txtEmail = (TextView) findViewById(R.id.email);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        
        submit = (Button)findViewById(R.id.button1);
        
        health = (Button) findViewById(R.id.button2);
 
        // SqLite database handler
        db = new SQLiteHandler(getApplicationContext());
 
        // session manager
        session = new SessionManager(getApplicationContext());
 
        if (!session.isLoggedIn()) {
            logoutUser();
        }
 
        // Fetching user details from sqlite
        HashMap<String, String> user = db.getUserDetails();
 
        String name = user.get("name");
        String email = user.get("email");
 
        // Displaying the user details on the screen
       // txtName.setText(name);
        txtEmail.setText(email);
        
        submit.setOnClickListener(new View.OnClickListener() {
        	 
            @Override
            public void onClick(View v) {
            	EditText editText1 = (EditText)findViewById(R.id.editText1);

				String city = editText1.getText().toString();
				
				EditText editText2 = (EditText)findViewById(R.id.editText2);

				String specialization = editText2.getText().toString();
				
				Intent intent1= new Intent(MainActivity.this,ListView1.class);
				
				intent1.putExtra("city", city);
				 intent1.putExtra("specialization", specialization);
				 startActivity(intent1);
				
				
				
            }
        });
        
        health.setOnClickListener(new View.OnClickListener() {
       	 
            @Override
            public void onClick(View v) {
            	
				
				Intent intent2= new Intent(MainActivity.this,health.class);
				
			
				 startActivity(intent2);
				
				
				
            }
        });
        
        
 
        // Logout button click event
        btnLogout.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View v) {
                logoutUser();
            }
        });
    }
 
    /**
     * Logging out the user. Will set isLoggedIn flag to false in shared
     * preferences Clears the user data from sqlite users table
     * */
    private void logoutUser() {
        session.setLogin(false);
 
        db.deleteUsers();
 
        // Launching the login activity
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}