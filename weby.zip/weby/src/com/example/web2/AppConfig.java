package com.example.web2;

public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http:///";
 
    // Server user register url
    public static String URL_REGISTER = "http://10.99.3.179/";
    
    public static String URL_VIEW = "http://10.99.3.179/connection.php";
    
    public static String URL_RATING = "http://10.99.3.179/rating.php";
    
    public static String URL_SHOW = "http://10.99.3.179/show.php";
    
}