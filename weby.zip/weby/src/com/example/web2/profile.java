package com.example.web2;


import java.io.BufferedReader; 
import java.io.IOException; 
import java.io.InputStream; 
import java.io.InputStreamReader;
import java.util.ArrayList; 
import java.util.HashMap; 
import java.util.List;
import java.util.Map;   
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException; 
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost; 
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray; 
import org.json.JSONException; 
import org.json.JSONObject;




import android.os.AsyncTask; import android.os.Bundle; import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class profile extends Activity {
    private String jsonResult;
    private String eng,med,bus,arch,l,opt=null;
    private String url = AppConfig.URL_VIEW;
    private String rate = AppConfig.URL_RATING;
    private String show = AppConfig.URL_SHOW;
    private ListView listView;
    
    private TextView t1;
    float r1;
    int num_user=0;
    int r=0;
    
    private RatingBar ra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        listView = (ListView) findViewById(R.id.listView1);
        
        ra= (RatingBar) findViewById(R.id.ratingBar1);
        t1 = (TextView) findViewById(R.id.textView2);
        
        accessWebService();
        

        ra.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                 r1=rating;
                 
                 float h = (r1 + r ) / (num_user  + 1 );
               
                 t1.setText(String.valueOf(h));


            }
        });

       
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;  }    // Async Task to access the web
    private class JsonReadTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(params[0]);
            try {
                HttpResponse response = httpclient.execute(httppost);
                jsonResult = inputStreamToString(       response.getEntity().getContent()).toString();
            }      catch (ClientProtocolException e) {
                e.printStackTrace();
            }
            catch (IOException e) {     e.printStackTrace();    }
            return null;
        }
        private StringBuilder inputStreamToString(InputStream is) {
            String rLine = "";
            StringBuilder answer = new StringBuilder();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            try {
                while ((rLine = rd.readLine()) != null) {
                    answer.append(rLine);
                }
            }
            catch (IOException e) {     // e.printStackTrace();

                Toast.makeText(getApplicationContext(),
                        "Error..." + e.toString(), Toast.LENGTH_LONG).show();
            }
            return answer;   }
        @Override
        protected void onPostExecute(String result) {    ListDrwaer();   }  }// end async task
    
    private class JsonReadRate extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(params[0]);
            try {
                HttpResponse response = httpclient.execute(httppost);
                jsonResult = inputStreamToString(response.getEntity().getContent()).toString();
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        private StringBuilder inputStreamToString(InputStream is) {
            String rLine = "";
            StringBuilder answer = new StringBuilder();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            try {
                while ((rLine = rd.readLine()) != null) {
                    answer.append(rLine);
                }
            } catch (IOException e) {     // e.printStackTrace();

                Toast.makeText(getApplicationContext(),
                        "Error..." + e.toString(), Toast.LENGTH_LONG).show();
            }
            return answer;
        }

        @Override
        protected void onPostExecute(String result) {
            ListRate();
        }
    }// end async task
    
    
    private class JsonReadShow extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(params[0]);
            try {
                HttpResponse response = httpclient.execute(httppost);
                jsonResult = inputStreamToString(response.getEntity().getContent()).toString();
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        private StringBuilder inputStreamToString(InputStream is) {
            String rLine = "";
            StringBuilder answer = new StringBuilder();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            try {
                while ((rLine = rd.readLine()) != null) {
                    answer.append(rLine);
                }
            } catch (IOException e) {     // e.printStackTrace();

                Toast.makeText(getApplicationContext(),
                        "Error..." + e.toString(), Toast.LENGTH_LONG).show();
            }
            return answer;
        }

        @Override
        protected void onPostExecute(String result) {
            ListSh();
        }
    }// end async task
    
    
    
    
 
    public void accessWebService() {   JsonReadTask task = new JsonReadTask();   // passes values for the urls string array
        task.execute(new String[] { url });  }  
    
    public void accessWebService2() {   JsonReadRate task = new JsonReadRate();   // passes values for the urls string array
    task.execute(new String[] { rate });  } 
    
    public void accessWebService3() {   JsonReadShow task = new JsonReadShow();   // passes values for the urls string array
    task.execute(new String[] { show });  } 
    
    
    
    // build hash set for list view
    public void ListDrwaer() {
        List<Map<String, String>> univList = new ArrayList<Map<String, String>>();
        try{    JSONObject jsonResponse = new JSONObject(jsonResult);
            JSONArray jsonMainNode = jsonResponse.optJSONArray("doctor");
            Intent i1 = getIntent(); 
            String profile1 = i1.getStringExtra("name");
            
            TextView prolo = (TextView)findViewById(R.id.textView1);
    		prolo.setText(profile1);
    		
    		accessWebService2();
            

            for (int i = 0; i < jsonMainNode.length(); i++)
            {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
                String name1 = jsonChildNode.optString("name");
                String email1 = jsonChildNode.optString("email");
                String location1 = jsonChildNode.optString("location");
                String city1 = jsonChildNode.optString("city");
                String phone1 = jsonChildNode.optString("phone");
                String special1 = jsonChildNode.optString("specialization");
                String outPut = name1;
                
                special1 = "Specialization : " + special1;
                email1 = "Email : " + email1;
                location1 = "Location : " + location1 ;
                city1 = "City : " + city1;
                phone1 = "Contact : " + phone1 ;
                
                if(name1.equals(profile1)  )
                {
               
                univList.add(createUniv("doctor", special1 ));
                univList.add(createUniv("doctor", email1 ));
                univList.add(createUniv("doctor", location1 ));
                univList.add(createUniv("doctor", city1 ));
                univList.add(createUniv("doctor", phone1 ));
                
                
                
                
                
                }
                
               

                


            }   }
        catch (JSONException e) {
            Toast.makeText(getApplicationContext(), "Error" + e.toString(),
                    Toast.LENGTH_SHORT).show();   }
        
        SimpleAdapter simpleAdapter = new SimpleAdapter(this, univList,     android.R.layout.simple_list_item_1,     new String[] { "doctor" }, new int[] { android.R.id.text1 });
        listView.setAdapter(simpleAdapter); 
        
        
    }
        
     public void ListRate() {
            List<Map<String, String>> univList = new ArrayList<Map<String, String>>();
            try {
                JSONObject jsonResponse = new JSONObject(jsonResult);
                JSONArray jsonMainNode = jsonResponse.optJSONArray("rat");
                
                Intent i1 = getIntent(); 
                String prof = i1.getStringExtra("name");

     num_user=0;
      r=0;
    float fi_rat=0;

                for (int i = 0; i < jsonMainNode.length(); i++) {
                    JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
                    String doc_name = jsonChildNode.optString("name");
                    String num= jsonChildNode.optString("users");
                    String star = jsonChildNode.optString("stars");
                  
                    String outPut = "";

                    if(prof.equals(doc_name))
                    {
                        r=Integer.parseInt(star);
                        num_user=Integer.parseInt(num);
                                
                    }
                }
    fi_rat=r/num_user;
                t1.setText(String.valueOf(fi_rat));
            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Error" + e.toString(),
                        Toast.LENGTH_SHORT).show();
            }


    
    
    
    }
    
     
     public void ListSh() {
         List<Map<String, String>> univList = new ArrayList<Map<String, String>>();
         try {
             JSONObject jsonResponse = new JSONObject(jsonResult);
             JSONArray jsonMainNode = jsonResponse.optJSONArray("sho");
             
             Intent i1 = getIntent(); 
             String prof = i1.getStringExtra("name");

 int num_user=0;
 int rate=0;
 float s1=0;
 
 t1.setText("anuhwdu");
 

             for (int i = 0; i < jsonMainNode.length(); i++)
             {
                 JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
                 String doc_name = jsonChildNode.optString("name");
                 String num= jsonChildNode.optString("users");
                 String star = jsonChildNode.optString("stars");
               
                 

                 if(prof.equals(doc_name))
                 {
                     rate=Integer.parseInt(star);
                     num_user=Integer.parseInt(num);
                             
                 }
             }
      s1=rate/num_user;
             t1.setText(String.valueOf(s1));
         } catch (JSONException e) {
             Toast.makeText(getApplicationContext(), "Error" + e.toString(),
                     Toast.LENGTH_SHORT).show();
         }


 
 
 
 }
 
    

    private HashMap<String, String> createUniv(String name, String number) {
        HashMap<String, String> univInfo = new HashMap<String, String>();
        univInfo.put(name, number);
        return univInfo;
    } }


